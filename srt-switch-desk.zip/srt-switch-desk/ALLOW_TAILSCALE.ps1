# Run in an Administrator PowerShell if incoming traffic is blocked.
$ErrorActionPreference = 'Stop'
New-NetFirewallRule -DisplayName 'SRT Desk SRT (Tailscale)' -Direction Inbound -Action Allow -Protocol UDP -LocalPort 8890 -RemoteAddress 100.64.0.0/10 -Profile Any
New-NetFirewallRule -DisplayName 'SRT Desk Web (Tailscale)' -Direction Inbound -Action Allow -Protocol TCP -LocalPort 8765 -RemoteAddress 100.64.0.0/10 -Profile Any
New-NetFirewallRule -DisplayName 'SRT Desk WebRTC UDP (Tailscale)' -Direction Inbound -Action Allow -Protocol UDP -LocalPort 8189 -RemoteAddress 100.64.0.0/10 -Profile Any
New-NetFirewallRule -DisplayName 'SRT Desk WebRTC TCP (Tailscale)' -Direction Inbound -Action Allow -Protocol TCP -LocalPort 8189 -RemoteAddress 100.64.0.0/10 -Profile Any
Write-Host 'Allowed SRT, WebRTC and web access from Tailscale IPv4 peers.'
