param([int]$HttpsPort = 8443, [string]$PagesUrl = '')
$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
$pythonExe = Join-Path $PSScriptRoot '.venv\Scripts\python.exe'
$helperPath = Join-Path $PSScriptRoot 'connect_github.py'
if (-not (Test-Path $pythonExe)) { throw 'Run START_GITHUB.bat to install the Python environment first.' }
if (-not (Test-Path $helperPath)) { throw 'connect_github.py is missing. Extract all updated receiver files into the same folder.' }
$helperArgs = @($helperPath, '--https-port', [string]$HttpsPort)
if ($PagesUrl) { $helperArgs += @('--pages-url', $PagesUrl) }
& $pythonExe @helperArgs
if ($LASTEXITCODE -ne 0) { throw 'Tailscale setup failed. Read the message above and try again.' }
