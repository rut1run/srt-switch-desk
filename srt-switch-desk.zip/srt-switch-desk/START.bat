@echo off
cd /d "%~dp0"
if not exist .venv\Scripts\python.exe goto setup
if not exist mediamtx.exe goto setup
if not exist web\hls.min.js goto setup
if not exist ffmpeg.exe (
  where ffmpeg >nul 2>nul
  if errorlevel 1 goto setup
)
goto launch
:setup
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0setup.ps1"
if errorlevel 1 goto end
:launch
if "%SRT_DESK_GITHUB%"=="1" (
  powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0CONNECT_GITHUB.ps1"
  if errorlevel 1 goto end
)
.venv\Scripts\python.exe start.py
:end
pause
