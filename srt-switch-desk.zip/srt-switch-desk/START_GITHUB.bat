@echo off
setlocal
cd /d "%~dp0"
set SRT_DESK_GITHUB=1
call START.bat
endlocal
