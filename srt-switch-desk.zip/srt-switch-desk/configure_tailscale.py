"""Configure this receiver before startup. Never exports credentials to the public files."""
import argparse,socket,sys
from pathlib import Path
from urllib.parse import urlsplit
root=Path(__file__).resolve().parent
sys.path.insert(0,str(root/'server'))
def validate_pages_url(value):
    u=urlsplit(value)
    if u.scheme!='https' or not u.hostname or not u.hostname.endswith('.github.io') or u.username or u.password or u.query or u.fragment:
        raise ValueError('Use the HTTPS github.io URL of your published site.')
    return value.rstrip('/')+'/'
def main():
    p=argparse.ArgumentParser();p.add_argument('--host',required=True);p.add_argument('--origin',required=True);p.add_argument('--pages-url',default='');args=p.parse_args()
    u=urlsplit(args.origin)
    if u.scheme!='https' or not u.hostname or not u.hostname.endswith('.ts.net') or u.username or u.password or u.path not in ('','/') or u.query or u.fragment:raise SystemExit('Invalid Tailscale HTTPS origin')
    try:
        with socket.create_connection(('127.0.0.1',8765),timeout=.3):raise SystemExit('Stop the running receiver with Ctrl+C, then run START_GITHUB.bat again.')
    except OSError:pass
    from app import cfg,save
    cfg['host']=args.host;cfg['tailscale_origin']=args.origin.rstrip('/')
    if args.pages_url:cfg['pages_url']=validate_pages_url(args.pages_url)
    save();print('Tailscale receiver URL: '+cfg['tailscale_origin'])
    print('SRT receiver IP: '+cfg['host'])
if __name__=='__main__':main()
