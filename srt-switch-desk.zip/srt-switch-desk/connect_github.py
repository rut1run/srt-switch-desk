"""Read Tailscale's UTF-8 JSON directly, bypassing Windows PowerShell text decoding."""
import argparse,ipaddress,json,os,shutil,socket,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
TARGET='http://127.0.0.1:8765'
def run_json(exe,args):
    result=subprocess.run([str(exe),*args],stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=20,check=False)
    if result.returncode:
        raise RuntimeError('Tailscale command failed: '+' '.join(args)+'. Check that Tailscale is running and signed in.')
    try:
        # The child process writes UTF-8 bytes. Never pass JSON through PowerShell.
        value=json.loads(result.stdout.decode('utf-8-sig') or '{}')
    except (UnicodeError,json.JSONDecodeError):
        raise RuntimeError('Tailscale did not return valid UTF-8 JSON. Update Tailscale and try again.') from None
    if value is None:return {}
    if not isinstance(value,dict):raise RuntimeError('Unexpected Tailscale response.')
    return value

def receiver_identity(status):
    if status.get('BackendState')!='Running':raise RuntimeError('Connect Tailscale before continuing.')
    own=status.get('Self') or {};name=str(own.get('DNSName') or '').rstrip('.')
    addresses=own.get('TailscaleIPs') or status.get('TailscaleIPs') or []
    address=next((ip for ip in addresses if ':' not in ip and ipaddress.ip_address(ip) in ipaddress.ip_network('100.64.0.0/10')),None)
    if not name.endswith('.ts.net') or not address:raise RuntimeError('Tailscale DNS name or IPv4 address was not found. Enable MagicDNS.')
    return name,address

def check_conflict(config,port):
    for key,value in (config.get('Web') or {}).items():
        if not key.endswith(':'+str(port)):continue
        handler=(value.get('Handlers') or {}).get('/')
        if handler and handler.get('Proxy')!=TARGET:
            raise RuntimeError(f'HTTPS port {port} is already used by another service. Use -HttpsPort with another port.')

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--https-port',type=int,default=8443);parser.add_argument('--pages-url',default='');args=parser.parse_args()
    if not 1<=args.https_port<=65535:raise RuntimeError('HTTPS port must be between 1 and 65535.')
    try:
        with socket.create_connection(('127.0.0.1',8765),timeout=.3):
            raise RuntimeError('Stop the running receiver with Ctrl+C, then run START_GITHUB.bat again.')
    except OSError:pass
    exe=shutil.which('tailscale') or str(Path(os.environ.get('ProgramFiles','C:/Program Files'))/'Tailscale/tailscale.exe')
    if not Path(exe).is_file():raise RuntimeError('Tailscale was not found. Install it and sign in first.')
    name,address=receiver_identity(run_json(exe,['status','--json']))
    check_conflict(run_json(exe,['serve','status','--json']),args.https_port)
    print('Enabling private Tailscale HTTPS access...',flush=True)
    # Inherit the console so Tailscale can show any HTTPS activation link.
    result=subprocess.run([exe,'serve','--bg',f'--https={args.https_port}',TARGET],check=False)
    if result.returncode:raise RuntimeError('Enable HTTPS/Serve using the URL shown above, then run START_GITHUB.bat again.')
    origin=f'https://{name}:{args.https_port}'
    command=[sys.executable,str(ROOT/'configure_tailscale.py'),'--host',address,'--origin',origin]
    if args.pages_url:command.extend(['--pages-url',args.pages_url])
    result=subprocess.run(command,cwd=ROOT,check=False)
    if result.returncode:raise RuntimeError('Receiver configuration failed. Read the message above.')
    print('HTTPS is ready. The receiver will start next.')
    return 0

if __name__=='__main__':
    try:raise SystemExit(main())
    except (RuntimeError,OSError,subprocess.TimeoutExpired) as exc:
        print('Setup error: '+str(exc),file=sys.stderr);raise SystemExit(1)
