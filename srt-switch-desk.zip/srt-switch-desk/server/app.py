import asyncio, base64, hashlib, hmac, json, os, secrets, time, uuid
from pathlib import Path
from urllib.parse import quote, urlsplit
import httpx, websockets
from fastapi import FastAPI, Request, HTTPException, Depends
from fastapi.responses import Response, FileResponse, StreamingResponse
from contextlib import asynccontextmanager
from relay import supervise
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from starlette.datastructures import Headers
from pydantic import BaseModel, Field

ROOT = Path(__file__).resolve().parent.parent
DATA = Path(os.environ.get('SRT_DESK_DATA', ROOT / 'data'))
DATA.mkdir(exist_ok=True, parents=True)
FILE = DATA / 'config.json'
def channel(i):
    return {'id': f'cam{i}', 'name': f'PC {i:02}', 'password': secrets.token_hex(12)}
if FILE.exists():
    cfg = json.loads(FILE.read_text('utf-8'))
else:
    cfg = {'admin_token': secrets.token_urlsafe(32), 'read_token': secrets.token_hex(20),
           'host': '127.0.0.1', 'width': 1920, 'height': 1080, 'fit': 'contain',
           'mode': 'output', 'obs_host': '127.0.0.1', 'obs_port': 4455, 'obs_password': '',
           'web_origin': 'http://127.0.0.1:8765', 'channels': [channel(i) for i in range(1,5)]}
def save():
    temp=FILE.with_suffix('.tmp'); temp.write_text(json.dumps(cfg,ensure_ascii=False,indent=2),'utf-8')
    try: os.chmod(temp,0o600)
    except OSError: pass
    temp.replace(FILE)
cfg.setdefault('bridge_token',secrets.token_hex(24))
cfg.setdefault('srt_latency',120)
cfg.setdefault('pages_url','')
cfg.setdefault('tailscale_origin','')
cfg.setdefault('switcher',{'layout':1,'sources':[],'audio':{'master_db':0,'muted':False,'normalize':True,'target_db':-18,'mode':'main','channels':{}}})
save()
program = next(iter(cfg['switcher']['sources']),None)
program_revision=0
boot_id=uuid.uuid4().hex
switch_lock = asyncio.Lock()
relay_status={'ready':set(),'ffmpeg':False}
output_subscribers=set()
@asynccontextmanager
async def lifespan(app):
    task=asyncio.create_task(supervise(cfg,paths,ROOT,DATA,relay_status))
    try:yield
    finally:
        task.cancel()
        try:await task
        except asyncio.CancelledError:pass
app = FastAPI(docs_url=None, redoc_url=None,lifespan=lifespan)
# Explicit Bearer authentication remains mandatory for all admin operations.
class LocalNetworkCORS(CORSMiddleware):
    def preflight_response(self,request_headers):
        requested=request_headers.get('access-control-request-private-network')=='true'
        clean=Headers({k:v for k,v in request_headers.items() if k.lower()!='access-control-request-private-network'}) if requested else request_headers
        response=super().preflight_response(clean)
        if requested and response.status_code==200:
            response.headers['Access-Control-Allow-Private-Network']='true'
        return response
app.add_middleware(LocalNetworkCORS, allow_origins=['*'], allow_methods=['GET','POST','DELETE'], allow_headers=['Authorization','Content-Type'], allow_credentials=False)
async def admin(r: Request):
    if not hmac.compare_digest(r.headers.get('authorization',''), 'Bearer '+cfg['admin_token']):
        raise HTTPException(401, '管理キーが違います')
def get_channel(cid):
    for c in cfg['channels']:
        if c['id']==cid: return c
    raise HTTPException(404,'入力がありません')
def b64hash(s): return base64.b64encode(hashlib.sha256(s.encode()).digest()).decode()
class OBS:
    async def __aenter__(self):
        try:
            self.ws=await websockets.connect(f"ws://{cfg['obs_host']}:{cfg['obs_port']}",open_timeout=4, max_size=4*1024*1024)
            hello=json.loads(await asyncio.wait_for(self.ws.recv(),5))['d']
            ident={'rpcVersion':1,'eventSubscriptions':0}
            if 'authentication' in hello:
                a=hello['authentication']; ident['authentication']=b64hash(b64hash(cfg['obs_password']+a['salt'])+a['challenge'])
            await self.ws.send(json.dumps({'op':1,'d':ident}))
            msg=json.loads(await asyncio.wait_for(self.ws.recv(),5))
            if msg.get('op')!=2: raise RuntimeError('OBSの認証に失敗しました')
            return self
        except Exception:
            if hasattr(self,'ws'): await self.ws.close()
            raise
    async def __aexit__(self,*args): await self.ws.close()
    async def call(self,typ,data=None):
        rid=str(uuid.uuid4())
        await self.ws.send(json.dumps({'op':6,'d':{'requestType':typ,'requestId':rid,'requestData':data or {}}}))
        while True:
            msg=json.loads(await asyncio.wait_for(self.ws.recv(),8))
            if msg.get('op')==7 and msg['d']['requestId']==rid:
                d=msg['d']
                if not d['requestStatus']['result']:
                    raise RuntimeError(d['requestStatus'].get('comment') or f'OBSエラー {typ}')
                return d.get('responseData',{})
async def paths():
    async with httpx.AsyncClient(timeout=3,trust_env=False) as h:
        res=await h.get('http://127.0.0.1:9997/v3/paths/list'); res.raise_for_status()
        return res.json()['items']
@app.get('/api/state', dependencies=[Depends(admin)])
async def state():
    result={k:v for k,v in cfg.items() if k not in ('admin_token','obs_password','bridge_token')}
    result['obs_password_saved']=bool(cfg['obs_password']);result['program']=program;result['ffmpeg_ready']=relay_status['ffmpeg'];result['transport']='webrtc'
    try:
        ps=await paths();ready={p['name']:p for p in ps};result['receiver']='connected'
        result['channels']=[{**c,'ready':bool(ready.get(c['id'],{}).get('ready')),'rtc_ready':bool(ready.get(c['id']+'_rtc',{}).get('ready')),'bytes':ready.get(c['id'],{}).get('bytesReceived',0)} for c in cfg['channels']]
    except Exception:
        result['receiver']='disconnected'; result['channels']=[{**c,'ready':False,'rtc_ready':False,'bytes':0} for c in cfg['channels']]
    return result
class Settings(BaseModel):
    host: str = Field(min_length=1,max_length=253)
    width: int = Field(ge=320,le=7680)
    height: int = Field(ge=240,le=4320)
    fit: str
    mode: str
    obs_host: str=Field(min_length=1,max_length=253)
    obs_port: int=Field(ge=1,le=65535)
    obs_password: str | None = None
    web_origin: str
    srt_latency: int = Field(default=120,ge=40,le=2000)
@app.post('/api/settings', dependencies=[Depends(admin)])
async def settings(s:Settings):
    if s.fit not in ['contain','cover','fill'] or s.mode not in ['media','browser','output']:
        raise HTTPException(422,'設定値が無効です')
    if any(x in s.host for x in '/?&#:@ ') or any(x in s.obs_host for x in '/?&#:@ '):
        raise HTTPException(422,'ホスト名またはIPv4アドレスを入力してください')
    u=urlsplit(s.web_origin)
    if u.scheme not in ['http','https'] or not u.hostname or u.username or u.password or u.query or u.fragment:
        raise HTTPException(422,'サイトのURLが無効です')
    async with switch_lock:
        data=s.model_dump();data['web_origin']=s.web_origin.rstrip('/')
        if data['obs_password'] is None: data.pop('obs_password')
        cfg.update(data);save()
    return {'ok':True}
class PagesSettings(BaseModel):
    pages_url:str=Field(max_length=500)
@app.post('/api/pages',dependencies=[Depends(admin)])
async def pages_settings(d:PagesSettings):
    url=d.pages_url.strip()
    if url:
        u=urlsplit(url)
        if u.scheme!='https' or not u.hostname or not u.hostname.endswith('.github.io') or u.username or u.password or u.query or u.fragment:
            raise HTTPException(422,'公開したhttps://から始まるgithub.ioのURLを指定してください')
        url=url.rstrip('/')+'/'
    async with switch_lock:
        cfg['pages_url']=url;save()
    return {'ok':True,'pages_url':url,'tailscale_origin':cfg['tailscale_origin']}
class ChannelInput(BaseModel):
    name:str=Field(min_length=1,max_length=60)
@app.post('/api/channels',dependencies=[Depends(admin)])
async def add_channel(data:ChannelInput):
    async with switch_lock:
        if len(cfg['channels'])>=16: raise HTTPException(422,'入力は最大16件です')
        i=1
        while any(c['id']==f'cam{i}' for c in cfg['channels']): i+=1
        c=channel(i);c['name']=data.name;cfg['channels'].append(c);save()
    return c
@app.post('/api/channels/{cid}/rename',dependencies=[Depends(admin)])
async def rename(cid:str,data:ChannelInput):
    async with switch_lock:
        get_channel(cid)['name']=data.name;save()
    return {'ok':True}
@app.post('/api/channels/{cid}/delete',dependencies=[Depends(admin)])
async def delete(cid:str):
    async with switch_lock:
        if cid==program or cid in cfg['switcher']['sources']:raise HTTPException(409,'送出中の入力は削除できません')
        get_channel(cid);cfg['channels']=[c for c in cfg['channels'] if c['id']!=cid];cfg['switcher']['audio']['channels'].pop(cid,None);save();notify_output()
    return {'ok':True}
@app.post('/internal/media-auth')
async def media_auth(r:Request):
    if r.client.host not in ('127.0.0.1','::1'):raise HTTPException(403)
    d=await r.json(); action=d.get('action'); user=d.get('user',''); password=d.get('password','')
    if action=='api' and d.get('ip') in ('127.0.0.1','::1'):return {}
    if action=='read' and user=='viewer' and hmac.compare_digest(password,cfg['read_token']):return {}
    if action=='publish' and user=='bridge' and d.get('ip') in ('127.0.0.1','::1') and hmac.compare_digest(password,cfg['bridge_token']):
        if any(d.get('path')==c['id']+'_rtc' for c in cfg['channels']):return {}
    if action=='publish':
        c=next((c for c in cfg['channels'] if c['id']==d.get('path')),None)
        if c and user=='sender' and hmac.compare_digest(password,c['password']):return {}
    raise HTTPException(403)
@app.post('/api/obs/test',dependencies=[Depends(admin)])
async def obs_test():
    try:
        async with OBS() as obs:
            ver=await obs.call('GetVersion'); scene=await obs.call('GetCurrentProgramScene');video=await obs.call('GetVideoSettings')
        return {'ok':True,**ver,**scene,**video}
    except Exception as e:raise HTTPException(502,f'OBSに接続できません: {e}')
def player_url(cid):return f"{cfg['web_origin']}/player.html?stream={cid}&token={cfg['read_token']}"
def media_url(cid):return f"srt://{cfg['host']}:8890?mode=caller&streamid=read:{cid}:viewer:{cfg['read_token']}&latency={cfg['srt_latency']*1000}"
@app.post('/api/obs/prepare',dependencies=[Depends(admin)])
async def prepare():
    if cfg['mode']=='output':return {'ok':True,'message':'出力ページのURLをOBSのブラウザソースに追加してください'}
    async with switch_lock:
        try:
            async with OBS() as obs:
                scenes=await obs.call('GetSceneList');names={s['sceneName'] for s in scenes['scenes']}
                inputs=await obs.call('GetInputList');input_names={s['inputName'] for s in inputs['inputs']}
                for c in cfg['channels']:
                    scene='SRT · '+c['id']; source='SRT · '+c['id']+' · '+cfg['mode']
                    if scene not in names:await obs.call('CreateScene',{'sceneName':scene})
                    sett={'is_local_file':False,'input':media_url(c['id']),'input_format':'mpegts','restart_on_activate':False,'close_when_inactive':False,'reconnect_delay_sec':1,'buffering_mb':2} if cfg['mode']=='media' else {'url':player_url(c['id']),'width':cfg['width'],'height':cfg['height'],'shutdown':False,'restart_when_active':False,'reroute_audio':True}
                    kind='ffmpeg_source' if cfg['mode']=='media' else 'browser_source'
                    if source not in input_names:
                        await obs.call('CreateInput',{'sceneName':scene,'inputName':source,'inputKind':kind,'inputSettings':sett,'sceneItemEnabled':True})
                    else:
                        await obs.call('SetInputSettings',{'inputName':source,'inputSettings':sett,'overlay':True})
                        items=await obs.call('GetSceneItemList',{'sceneName':scene})
                        if not any(i['sourceName']==source for i in items['sceneItems']):await obs.call('CreateSceneItem',{'sceneName':scene,'sourceName':source,'sceneItemEnabled':True})
                    items=await obs.call('GetSceneItemList',{'sceneName':scene})
                    for item in items['sceneItems']:
                        if item['sourceName'].startswith('SRT · '+c['id']+' · '):
                            await obs.call('SetSceneItemEnabled',{'sceneName':scene,'sceneItemId':item['sceneItemId'],'sceneItemEnabled':item['sourceName']==source})
                    item=await obs.call('GetSceneItemId',{'sceneName':scene,'sourceName':source})
                    await obs.call('SetSceneItemTransform',{'sceneName':scene,'sceneItemId':item['sceneItemId'],'sceneItemTransform':{'positionX':cfg['width']/2,'positionY':cfg['height']/2,'alignment':0,'boundsAlignment':0,'boundsType':{'contain':'OBS_BOUNDS_SCALE_INNER','cover':'OBS_BOUNDS_SCALE_OUTER','fill':'OBS_BOUNDS_STRETCH'}[cfg['fit']],'boundsWidth':cfg['width'],'boundsHeight':cfg['height']}})
            return {'ok':True,'message':f"{len(cfg['channels'])}入力をOBSに登録しました"}
        except Exception as e:raise HTTPException(502,f'OBS登録に失敗しました: {e}')
@app.post('/api/take/{cid}',dependencies=[Depends(admin)])
async def take(cid:str):
    global program,program_revision
    async with switch_lock:
        get_channel(cid)
        try: ps=await paths()
        except Exception:raise HTTPException(503,'受信サーバーに接続できません')
        if not any(p['name']==cid and p.get('ready') for p in ps):raise HTTPException(409,'この入力は受信していません')
        if cfg['mode']!='media' and not any(p['name']==cid+'_rtc' and p.get('ready') for p in ps):raise HTTPException(409,'WebRTCの準備中です。FFmpegと送信設定を確認してください')
        if cfg['mode']!='output':
            try:
                async with OBS() as obs:
                    await obs.call('SetCurrentProgramScene',{'sceneName':'SRT · '+cid})
                    actual=await obs.call('GetCurrentProgramScene')
                    if actual['currentProgramSceneName']!='SRT · '+cid:raise RuntimeError('切り替えを確認できませんでした')
            except Exception as e:raise HTTPException(502,f'OBS切替に失敗しました: {e}')
        program=cid
        cfg['switcher']['layout']=1;cfg['switcher']['sources']=[cid];save();notify_output()
    return {'ok':True,'program':program}
def notify_output():
    global program_revision
    program_revision+=1
    for q in list(output_subscribers):
        if q.full():q.get_nowait()
        q.put_nowait(program_revision)
class Composition(BaseModel):
    layout:int=Field(ge=1,le=3)
    sources:list[str]=Field(min_length=1,max_length=3)
@app.post('/api/composition',dependencies=[Depends(admin)])
async def composition(d:Composition):
    global program
    if d.layout!=len(d.sources) or len(set(d.sources))!=len(d.sources):raise HTTPException(422,'画面数と重複しない入力を指定してください')
    if cfg['mode']!='output':raise HTTPException(409,'設定の取り込み方法を「WebRTC出力ページ」にしてください')
    async with switch_lock:
        for cid in d.sources:get_channel(cid)
        try:ps=await paths()
        except Exception:raise HTTPException(503,'受信サーバーに接続できません')
        ready={p['name'] for p in ps if p.get('ready')}
        if any(cid+'_rtc' not in ready for cid in d.sources):raise HTTPException(409,'選んだ入力のWebRTC映像がまだ届いていません')
        cfg['switcher']['layout']=d.layout;cfg['switcher']['sources']=d.sources
        program=d.sources[0];save();notify_output()
    return {'ok':True,'switcher':cfg['switcher'],'program':program}
class ChannelAudio(BaseModel):
    db:float=Field(default=0,ge=-60,le=12)
    muted:bool=False
class AudioSettings(BaseModel):
    master_db:float=Field(default=0,ge=-60,le=12)
    muted:bool=False
    normalize:bool=True
    target_db:float=Field(default=-18,ge=-24,le=-12)
    mode:str='main'
    channels:dict[str,ChannelAudio]=Field(default_factory=dict,max_length=16)
@app.post('/api/audio',dependencies=[Depends(admin)])
async def audio_settings(d:AudioSettings):
    if d.mode not in ('main','mix'):raise HTTPException(422,'音声のモードが無効です')
    async with switch_lock:
        for cid in d.channels:get_channel(cid)
        cfg['switcher']['audio']=d.model_dump();save();notify_output()
    return {'ok':True,'audio':cfg['switcher']['audio']}
@app.get('/api/output')
async def output(token:str):
    if not hmac.compare_digest(token,cfg['read_token']):raise HTTPException(403)
    return output_snapshot()

def output_snapshot():
    return {'program':program,'revision':program_revision,'boot_id':boot_id,'width':cfg['width'],'height':cfg['height'],'fit':cfg['fit'],'switcher':cfg['switcher'],
            'channels':[{'id':c['id'],'ready':c['id']+'_rtc' in relay_status['ready']} for c in cfg['channels']]}
@app.get('/api/events')
async def output_events(token:str,r:Request):
    if not hmac.compare_digest(token,cfg['read_token']):raise HTTPException(403)
    async def events():
        q=asyncio.Queue(maxsize=1);output_subscribers.add(q)
        try:
            yield 'data: '+json.dumps(output_snapshot())+'\n\n'
            while not await r.is_disconnected():
                try:await asyncio.wait_for(q.get(),1)
                except asyncio.TimeoutError:pass
                yield 'data: '+json.dumps(output_snapshot())+'\n\n'
        finally:output_subscribers.discard(q)
    return StreamingResponse(events(),media_type='text/event-stream',headers={'Cache-Control':'no-cache','X-Accel-Buffering':'no'})
@app.post('/rtc/{token}/{cid}')
async def rtc_offer(token:str,cid:str,r:Request):
    if not hmac.compare_digest(token,cfg['read_token']):raise HTTPException(403)
    get_channel(cid)
    raw=await r.body()
    if len(raw)>65536:raise HTTPException(413)
    try:
        async with httpx.AsyncClient(timeout=12,trust_env=False) as h:
            res=await h.post(f'http://127.0.0.1:8889/{cid}_rtc/whep',content=raw,headers={'Content-Type':'application/sdp'},auth=('viewer',cfg['read_token']))
        headers={'Content-Type':res.headers.get('content-type','application/sdp')}
        if 'location' in res.headers:
            # Only retain MediaMTX's opaque session id, never a remote URL.
            sid=res.headers['location'].rstrip('/').split('/')[-1]
            headers['Location']=f'/rtc/{token}/{cid}/{sid}'
            headers['Access-Control-Expose-Headers']='Location'
        return Response(res.content,status_code=res.status_code,headers=headers)
    except Exception:raise HTTPException(503,'WebRTC受信サービスに接続できません')
@app.delete('/rtc/{token}/{cid}/{sid}')
async def rtc_close(token:str,cid:str,sid:str):
    if not hmac.compare_digest(token,cfg['read_token']):raise HTTPException(403)
    get_channel(cid)
    if not all(c.isalnum() or c=='-' for c in sid):raise HTTPException(400)
    async with httpx.AsyncClient(timeout=3,trust_env=False) as h:
        res=await h.delete(f'http://127.0.0.1:8889/{cid}_rtc/whep/{sid}',auth=('viewer',cfg['read_token']))
    return Response(status_code=res.status_code)

@app.get('/video/{token}/{cid}/{asset:path}')
async def video(token:str,cid:str,asset:str,r:Request):
    if not hmac.compare_digest(token,cfg['read_token']):raise HTTPException(403)
    get_channel(cid)
    if not asset or '..' in asset or '/' in asset or '\\' in asset or not all(x.isalnum() or x in '_.-' for x in asset):raise HTTPException(400)
    try:
        async with httpx.AsyncClient(timeout=15,trust_env=False,follow_redirects=True) as h:
            res=await h.get(f'http://127.0.0.1:8888/{cid}/{asset}',auth=('viewer',cfg['read_token']),params={k:v for k,v in r.query_params.items() if k in ('_HLS_msn','_HLS_part','_HLS_skip','session','cookieCheck')})
        return Response(res.content,status_code=res.status_code,headers={'Content-Type':res.headers.get('content-type','application/octet-stream'),'Cache-Control':'no-store'})
    except Exception:raise HTTPException(503,'映像に接続できません')
app.mount('/',StaticFiles(directory=ROOT/'web',html=True),name='web')
