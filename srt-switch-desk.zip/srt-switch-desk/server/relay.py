"""Copy H.264 without re-encoding; transcode only AAC audio into Opus."""
import asyncio,os,shutil,subprocess
from pathlib import Path

def ffmpeg_binary(root):
    bundled=root/('ffmpeg.exe' if os.name=='nt' else 'ffmpeg')
    return str(bundled) if bundled.exists() else shutil.which('ffmpeg')

async def supervise(cfg,paths,root,data,status):
    workers={};logs={};attempts={}
    async def stop(cid):
        p=workers.pop(cid,None)
        if p and p.returncode is None:
            try:
                p.terminate();await asyncio.wait_for(p.wait(),3)
            except asyncio.TimeoutError:
                p.kill();await p.wait()
            except ProcessLookupError:pass
        if cid in logs:logs.pop(cid).close()
    try:
        while True:
            binary=ffmpeg_binary(root);status['ffmpeg']=bool(binary)
            try:
                ps=await paths();ready={p['name'] for p in ps if p.get('ready')}
                status['ready']=ready
            except Exception:
                ready=set();status['ready']=set()
            wanted={c['id'] for c in cfg['channels'] if c['id'] in ready}
            for cid in list(workers):
                if cid not in wanted or workers[cid].returncode is not None:await stop(cid)
            if binary:
                for cid in wanted-workers.keys():
                    now=asyncio.get_running_loop().time()
                    if now-attempts.get(cid,-10)<3:continue
                    attempts[cid]=now
                    src=f"rtsp://viewer:{cfg['read_token']}@127.0.0.1:8554/{cid}"
                    dst=f"rtsp://bridge:{cfg['bridge_token']}@127.0.0.1:8554/{cid}_rtc"
                    args=[binary,'-hide_banner','-loglevel','warning','-nostdin','-rtsp_transport','tcp','-fflags','nobuffer','-flags','low_delay','-analyzeduration','1200000','-probesize','1000000','-i',src,'-map','0:v:0','-map','0:a:0?','-c:v','copy','-c:a','libopus','-application','lowdelay','-frame_duration','10','-b:a','96k','-ar','48000','-ac','2','-flush_packets','1','-rtsp_transport','tcp','-f','rtsp',dst]
                    logs[cid]=open(data/f'relay-{cid}.log','ab',buffering=0)
                    try:workers[cid]=await asyncio.create_subprocess_exec(*args,stdout=logs[cid],stderr=logs[cid],**({'creationflags':subprocess.CREATE_NO_WINDOW} if os.name=='nt' else {}))
                    except Exception:
                        logs.pop(cid).close()
            await asyncio.sleep(.5)
    finally:
        for cid in list(workers):await stop(cid)
