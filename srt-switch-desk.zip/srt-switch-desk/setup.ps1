$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
if (-not (Get-Command py -ErrorAction SilentlyContinue)) { throw 'Install Python 3.11 or newer from python.org first.' }
py -3 -m venv .venv
if ($LASTEXITCODE -ne 0) { throw 'Python environment creation failed' }
& .\.venv\Scripts\python.exe -m pip install -r requirements.txt
if ($LASTEXITCODE -ne 0) { throw 'Dependency installation failed' }
if (-not (Test-Path mediamtx.exe)) {
  $url = 'https://github.com/bluenviron/mediamtx/releases/download/v1.21.2/mediamtx_v1.21.2_windows_amd64.zip'
  Invoke-WebRequest $url -OutFile mediamtx-download.zip
  Expand-Archive mediamtx-download.zip -DestinationPath mediamtx-temp -Force
  Copy-Item mediamtx-temp\mediamtx.exe .\mediamtx.exe
  Remove-Item mediamtx-download.zip
  Remove-Item mediamtx-temp -Recurse -Force
}
if (-not (Test-Path web\hls.min.js)) {
  Invoke-WebRequest 'https://cdn.jsdelivr.net/npm/hls.js@1.6.13/dist/hls.min.js' -OutFile web\hls.min.js
}
if (-not (Test-Path ffmpeg.exe) -and -not (Get-Command ffmpeg -ErrorAction SilentlyContinue)) {
  Write-Host 'Downloading FFmpeg for low-latency audio conversion...'
  Invoke-WebRequest 'https://www.gyan.dev/ffmpeg/builds/ffmpeg-release-essentials.zip' -OutFile ffmpeg-download.zip
  Expand-Archive ffmpeg-download.zip -DestinationPath ffmpeg-temp -Force
  $ffmpegExe = Get-ChildItem ffmpeg-temp -Filter ffmpeg.exe -Recurse | Select-Object -First 1
  if (-not $ffmpegExe) { throw 'FFmpeg download did not contain ffmpeg.exe' }
  Copy-Item $ffmpegExe.FullName .\ffmpeg.exe
  Remove-Item ffmpeg-download.zip
  Remove-Item ffmpeg-temp -Recurse -Force
}
Write-Host 'Setup complete. Open START.bat.'

