import json, os, subprocess, sys, time, webbrowser
from pathlib import Path
from urllib.parse import urlencode
root=Path(__file__).resolve().parent
os.chdir(root)
sys.path.insert(0,str(root/'server'))
from app import cfg
exe=root/('mediamtx.exe' if os.name=='nt' else 'mediamtx')
if not exe.exists():
    print('MediaMTX not found. Run setup.ps1 first.');input('Enter to close');sys.exit(1)
print('\nSRT Switch Desk: http://127.0.0.1:8765\nAdmin key (do not share): '+cfg['admin_token']+'\n')
procs=[]
try:
    procs.append(subprocess.Popen([sys.executable,'-m','uvicorn','app:app','--app-dir',str(root/'server'),'--host','0.0.0.0','--port','8765','--no-access-log','--no-proxy-headers']))
    time.sleep(1)
    if os.environ.get('SRT_DESK_GITHUB')=='1' and cfg.get('pages_url') and cfg.get('tailscale_origin'):
        page=cfg['pages_url']+'#'+urlencode({'gateway':cfg['tailscale_origin'],'token':cfg['admin_token']})
        webbrowser.open(page)
    else:
        webbrowser.open('http://127.0.0.1:8765/#token='+cfg['admin_token'])
    if os.environ.get('SRT_DESK_GITHUB')=='1':
        print('GitHub Pages connection URL: '+cfg.get('tailscale_origin','Not configured'))
        if not cfg.get('pages_url'):print('Set the GitHub Pages URL in the local site Settings once. The next startup will open it automatically.')
    procs.append(subprocess.Popen([str(exe),str(root/'mediamtx.yml')]))
    while True:
        for p in procs:
            if p.poll() is not None:raise RuntimeError('A service stopped. Check the error above.')
        time.sleep(1)
except KeyboardInterrupt:pass
except Exception as e:print(e)
finally:
    for p in procs:
        p.terminate()
    for p in procs:
        try:p.wait(timeout=5)
        except subprocess.TimeoutExpired:p.kill()
