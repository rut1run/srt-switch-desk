'use strict';
window.DeskAudio=class DeskAudio {
 constructor(onMeter=()=>{},monitor=false){this.entries=new Map();this.settings={master_db:0,normalize:true,target_db:-18,mode:'main',channels:{}};this.visible=[];this.monitor=monitor;this.listen=!monitor;this.onMeter=onMeter;this.ctx=null;this.timer=setInterval(()=>this.tick(),50);}
 init(){if(this.ctx)return;const AC=window.AudioContext||window.webkitAudioContext;if(!AC)throw Error('Web Audio APIに対応していません');this.ctx=new AC({latencyHint:'interactive'});const c=this.ctx;
 this.master=c.createGain();this.limiter=c.createDynamicsCompressor();this.limiter.threshold.value=-4;this.limiter.knee.value=2;this.limiter.ratio.value=20;this.limiter.attack.value=.003;this.limiter.release.value=.15;
 this.output=c.createAnalyser();this.output.fftSize=2048;this.outputSamples=new Float32Array(2048);this.gate=c.createGain();this.gate.gain.value=this.listen?1:0;
 this.master.connect(this.limiter);this.limiter.connect(this.output);this.output.connect(this.gate);this.gate.connect(c.destination);
 for(const entry of this.entries.values())this.attach(entry);this.apply();}
 async resume(listen=this.listen){this.listen=listen;this.init();await this.ctx.resume();this.gate.gain.setTargetAtTime(listen?1:0,this.ctx.currentTime,.015);return this.ctx.state==='running';}
 add(id,stream){this.remove(id);const e={id,stream,source:null,autoDb:0,average:0};this.entries.set(id,e);e.onAdd=()=>this.attach(e);stream.addEventListener('addtrack',e.onAdd);this.attach(e);}
 attach(e){if(!this.ctx||e.source||!e.stream.getAudioTracks().length)return;const c=this.ctx;e.source=c.createMediaStreamSource(new MediaStream([e.stream.getAudioTracks()[0]]));e.analyser=c.createAnalyser();e.analyser.fftSize=2048;e.samples=new Float32Array(2048);e.auto=c.createGain();e.fader=c.createGain();e.fader.gain.value=0;e.source.connect(e.analyser);e.analyser.connect(e.auto);e.auto.connect(e.fader);e.fader.connect(this.master);this.apply();}
 remove(id){const e=this.entries.get(id);if(!e)return;e.stream.removeEventListener('addtrack',e.onAdd);for(const k of ['source','analyser','auto','fader'])try{e[k]?.disconnect();}catch{}this.entries.delete(id);}
 update(settings,visible){this.settings=settings||this.settings;this.visible=visible||[];this.apply();}
 apply(){if(!this.ctx)return;const s=this.settings,c=this.ctx;this.master.gain.setTargetAtTime(s.muted?0:DeskMixMath.dbToGain(s.master_db||0),c.currentTime,.02);
 const audible=s.mode==='mix'?this.visible:this.visible.slice(0,1);const mixScale=s.mode==='mix'&&audible.length>1?1/Math.sqrt(audible.length):1;
 for(const [id,e] of this.entries){if(!e.fader)continue;const ch=s.channels?.[id]||{};e.fader.gain.setTargetAtTime(audible.includes(id)&&!ch.muted?DeskMixMath.dbToGain(ch.db||0)*mixScale:0,c.currentTime,.012);if(!s.normalize){e.autoDb=0;e.auto.gain.setTargetAtTime(1,c.currentTime,.08);}}}
 tick(){if(!this.ctx||this.ctx.state!=='running')return;const levels={};for(const [id,e] of this.entries){if(!e.source)continue;e.analyser.getFloatTimeDomainData(e.samples);const rms=DeskMixMath.rms(e.samples);e.average=e.average===0?rms:e.average*.88+rms*.12;let desired=this.settings.normalize?DeskMixMath.gainDb(e.average,this.settings.target_db||-18):0;e.autoDb+=(desired-e.autoDb)*(desired < e.autoDb ? 0.4 : 0.035);e.auto.gain.setTargetAtTime(DeskMixMath.dbToGain(e.autoDb),this.ctx.currentTime,.025);levels[id]={db:20*Math.log10(Math.max(rms,1e-5)),adjustment:e.autoDb};}
 this.output.getFloatTimeDomainData(this.outputSamples);const db=20*Math.log10(Math.max(DeskMixMath.rms(this.outputSamples),1e-5));this.onMeter({channels:levels,master:db,running:true});}
 destroy(){clearInterval(this.timer);for(const id of [...this.entries.keys()])this.remove(id);this.ctx?.close().catch(()=>{});}
};
