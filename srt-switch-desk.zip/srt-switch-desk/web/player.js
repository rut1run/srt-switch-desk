'use strict';
const params=new URLSearchParams(location.search),token=params.get('token')||'',fixed=params.get('stream'),monitor=params.get('monitor')==='1',message=document.getElementById('outputMessage');document.getElementById('video').remove();
const pool=new Map();let desired=[],layout=1,fit='contain',source=null,polling=false,lastRevision=-1,boot=null,lastMeter=0;
const parentOrigin=(()=>{try{return new URL(document.referrer).origin;}catch{return location.origin;}})();
const status=document.createElement('button');status.className='audio-start';status.textContent=monitor?'音声メーターを有効にする':'クリックして音声を有効にする';status.style.display=monitor?'block':'none';document.body.append(status);
const audio=new DeskAudio(levels=>{if(monitor&&Date.now()-lastMeter>100){lastMeter=Date.now();parent.postMessage({type:'srt-audio-levels',...levels},parentOrigin);}},monitor);
async function resumeAudio(listen=!monitor){status.style.display='block';try{const ok=await audio.resume(listen);status.style.display=ok?'none':'block';return ok;}catch{status.style.display='block';status.textContent='音声を有効にするにはクリック';return false;}}
status.onclick=()=>resumeAudio(!monitor);message.onclick=()=>resumeAudio(!monitor);
window.addEventListener('message',e=>{if(e.source!==parent||e.origin!==parentOrigin)return;if(e.data?.type==='srt-monitor')resumeAudio(!!e.data.listen);});
function select(){const rects=DeskMixMath.rectangles(layout);for(const [id,p] of pool){const index=desired.indexOf(id);p.video.muted=true;p.video.volume=0;p.video.style.opacity=index>=0?'1':'0';p.video.style.objectFit=fit;
 if(index>=0){const r=rects[index];p.video.style.left=r[0]*100+'%';p.video.style.top=r[1]*100+'%';p.video.style.width=r[2]*100+'%';p.video.style.height=r[3]*100+'%';}}
 const ready=desired.length&&desired.every(id=>pool.get(id)?.playing);message.style.display=ready?'none':'flex';message.textContent=desired.length?'選択したWebRTC映像を待っています':'スイッチング画面で映像を選択してください';}
function add(id){const video=document.createElement('video');video.autoplay=true;video.playsInline=true;video.muted=true;video.style.cssText='position:absolute;left:0;top:0;opacity:0;pointer-events:none';document.getElementById('stage').append(video);const p={video,playing:false,stream:null};pool.set(id,p);
 video.onplaying=()=>{p.playing=true;select();};video.onwaiting=()=>{p.playing=false;select();};video.onerror=()=>{p.playing=false;select();};
 p.rtc=new DeskRTC(video,location.origin+'/rtc/'+encodeURIComponent(token)+'/'+encodeURIComponent(id),state=>{if(state!=='connected')p.playing=false;select();});
 // DeskRTC replaces srcObject on every reconnect. Reattach audio to the new MediaStream.
 p.attachTimer=setInterval(()=>{if(video.srcObject&&video.srcObject!==p.stream){p.stream=video.srcObject;audio.add(id,p.stream);}},100);
}
function apply(d){if(boot!==d.boot_id){boot=d.boot_id;lastRevision=-1;}if((d.revision||0)<lastRevision)return;lastRevision=d.revision||0;fit=d.fit||'contain';const sw=d.switcher||{layout:1,sources:d.program?[d.program]:[]};layout=fixed?1:sw.layout||1;desired=fixed?[fixed]:sw.sources||[];
 const stage=document.getElementById('stage');stage.style.aspectRatio=(d.width||1920)+' / '+(d.height||1080);
 const channels=fixed?[{id:fixed,ready:true}]:d.channels||[];const ids=new Set(channels.map(c=>c.id));for(const [id,p] of pool){if(!ids.has(id)){clearInterval(p.attachTimer);audio.remove(id);p.rtc.destroy();p.video.remove();pool.delete(id);}}for(const c of channels)if(c.ready&&!pool.has(c.id))add(c.id);audio.update(sw.audio,desired);select();}
async function refresh(){if(polling)return;polling=true;try{const r=await fetch('/api/output?token='+encodeURIComponent(token),{signal:AbortSignal.timeout(5000)});if(!r.ok)throw Error('出力キーを確認してください');apply(await r.json());}catch(e){message.style.display='flex';message.textContent=e.message;}finally{polling=false;}}
function events(){source=new EventSource('/api/events?token='+encodeURIComponent(token));source.onmessage=e=>{try{apply(JSON.parse(e.data));}catch{}};source.onerror=()=>refresh();}
refresh();events();resumeAudio(!monitor);const fallback=setInterval(refresh,5000);window.addEventListener('beforeunload',()=>{clearInterval(fallback);source?.close();for(const p of pool.values()){clearInterval(p.attachTimer);p.rtc.destroy();}audio.destroy();});
